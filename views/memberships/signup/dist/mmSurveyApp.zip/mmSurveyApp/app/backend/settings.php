<?php

// ------------------------------------------ //
// --- Main Settings ------------------------ //
// ------------------------------------------ //

 $varddf = ";Sdf";
  $DB_Username = "mayorgac_abogado";
  $DB_Password = "suaita.monteria";
  $DB_Host     = "localhost";
  $DB_Database   = "mayorgac_abogados";
  $DB_Table = "db_especialistas";

?>
